#ifndef __DDP_PWM_MUX_H__
#define __DDP_PWM_MUX_H__

int disp_pwm_set_pwmmux(unsigned int clk_req);

#endif
