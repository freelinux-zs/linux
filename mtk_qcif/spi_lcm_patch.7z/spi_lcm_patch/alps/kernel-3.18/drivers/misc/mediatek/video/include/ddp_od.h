#ifndef _OD_HW_REG_H__
#define _OD_HW_REG_H__

void od_test(const char *cmd, char *debug_output);


#endif
